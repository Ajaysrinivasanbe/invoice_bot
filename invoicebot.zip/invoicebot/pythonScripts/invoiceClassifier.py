import os
import pytesseract
import re
from PIL import Image
import pandas as pd

# Path to Tesseract executable
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# Folder containing invoice images
IMAGE_FOLDER = r'C:\invoicebot\Invoices'  # Change to your actual folder
OUTPUT_EXCEL = r'C:\invoicebot\Output\ProcessedInvoices.xlsx'  # Change path if needed

def extract_fields(text):
    result = {
        'Invoice Number': 'Not found',
        'Invoice Date': 'Not found',
        'Item Booked': 'Not found',
        'Shipping Address': 'Not found',
        'Total Cost': 0.0
    }

    # Invoice Number
    match = re.search(r'Invoice Number[:\-]?\s*([A-Z0-9\-]+)', text, re.IGNORECASE)
    if match:
        result['Invoice Number'] = match.group(1).strip()

    # Invoice Date
    match = re.search(r'Invoice Date[:\-]?\s*([0-9]{1,4}[./-][0-9]{1,2}[./-][0-9]{2,4})', text, re.IGNORECASE)
    if match:
        result['Invoice Date'] = match.group(1).strip()

    # Item Booked
    match = re.search(r'Item\s*Booked[:\-]?\s*(.+)', text, re.IGNORECASE)
    if match:
        result['Item Booked'] = match.group(1).strip()

    # Shipping Address
    match = re.search(r'Shipping Address[:\-]?\s*(.+?)(?:\n|$)', text, re.IGNORECASE)
    if match:
        result['Shipping Address'] = match.group(1).strip()

    # Total Cost
    match = re.search(r'(Invoice Value|Total Amount|Amount Paid)[:\-]?\s*[₹$]?\s*([\d,]+\.\d{2})', text, re.IGNORECASE)
    if match:
        # Remove commas and convert to float
        result['Total Cost'] = float(match.group(2).replace(',', ''))

    return result

def process_invoices(folder_path):
    data = []
    for file in os.listdir(folder_path):
        if file.lower().endswith(('.jpg', '.jpeg', '.png')):
            img_path = os.path.join(folder_path, file)
            try:
                img = Image.open(img_path)
                text = pytesseract.image_to_string(img)
                fields = extract_fields(text)
                fields['File Name'] = file
                data.append(fields)
                print(f"[✔] Processed: {file}")
            except Exception as e:
                print(f"[✖] Error with {file}: {e}")
    return data

def save_to_excel(data, output_path):
    df = pd.DataFrame(data)
    total_sum = df['Total Cost'].sum()
    
    # Append total row
    total_row = pd.DataFrame([{
        'Invoice Number': 'TOTAL',
        'Invoice Date': '',
        'Item Booked': '',
        'Shipping Address': '',
        'Total Cost': total_sum,
        'File Name': ''
    }])
    df = pd.concat([df, total_row], ignore_index=True)

    # Save to Excel
    df.to_excel(output_path, index=False)
    print(f"\n✅ Data exported to Excel: {output_path}")
    print(f"💰 Grand Total of All Invoices: ₹{total_sum:.2f}")

if __name__ == '__main__':
    extracted = process_invoices(IMAGE_FOLDER)
    if extracted:
        save_to_excel(extracted, OUTPUT_EXCEL)
    else:
        print("⚠ No invoice images found.")
