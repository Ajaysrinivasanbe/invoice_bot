RRTO
supports to other valid streams
twice in a week (thursday and friday)
JAVA
Oracle SQL DB (support role)
db: oracle and mongo db

sachin/yathindar/harish